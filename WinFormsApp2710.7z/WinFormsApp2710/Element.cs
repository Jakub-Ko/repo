﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp2710
{
    internal class Element
    {
        public int wartość;
        public Element next;
        public Element prev;
    }
}
