﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp2212
{
    internal class Wezel
    {
        public int wartosc;

        public Wezel(int wartosc)
        {
            this.wartosc = wartosc;
        }
    }
}
